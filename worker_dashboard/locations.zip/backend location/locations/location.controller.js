// src/locations/location.controller.js
const service = require("./location.service");

const getAllLocations = async (req, res) => {
  try {
    const data = await service.getAllLocations();
    res.json(data);
  } catch (err) {
  console.error("LOCATION DETAIL ERROR:", err.message);
  res.status(500).json({
    message: "Failed to fetch location detail",
    error: err.message
  });
}

};

const getLocationById = async (req, res) => {
  try {
    const data = await service.fetchLocationDetail(req.params.id);
    if (!data) {
      return res.status(404).json({ message: "Location not found" });
    }
    res.json(data);
  } catch (err) {
  console.error("LOCATION DETAIL ERROR:", err.message);
  res.status(500).json({
    message: "Failed to fetch location detail",
    error: err.message
  });
}

};

const updateLocation = async (req, res) => {
  try {
    const updated = await service.updateLocation(req.params.id, req.body);
    res.json(updated);
  } catch (err) {
  console.error("LOCATION DETAIL ERROR:", err.message);
  res.status(500).json({
    message: "Failed to fetch location detail",
    error: err.message
  });
}

};

const getWorkerLocation = async (req, res) => {
  try {
    const { workerId } = req.params;

    const data = await service.getWorkerLocation(workerId);

    if (!data) {
      return res.status(404).json({ message: "Worker location not found" });
    }

    res.json(data);
  } catch (err) {
    console.error("TRACK ERROR:", err.message);
    res.status(500).json({
      message: "Failed to fetch worker location",
      error: err.message,
    });
  }
};

const updateWorkerLocation = async (req, res) => {
  try {
    const data = await service.updateWorkerLocation(req.body);
    res.json(data);
  } catch (err) {
    console.error("UPDATE WORKER LOCATION ERROR:", err.message);
    res.status(500).json({
      message: "Failed to update worker location",
      error: err.message,
    });
  }
};

const getAllWorkerLocations = async (req, res) => {
  try {
    const data = await service.getAllWorkerLocations();

    if (!data || data.length === 0) {
      return res.status(404).json({
        message: "Worker location not found"
      });
    }

    res.json(data);
  } catch (err) {
    console.error("GET ALL WORKERS ERROR:", err.message);
    res.status(500).json({
      message: "Failed to fetch workers",
      error: err.message
    });
  }
};

module.exports = {
  getAllLocations,
  getLocationById,
  updateLocation,
  getWorkerLocation,
  updateWorkerLocation,
  getAllWorkerLocations,
};
