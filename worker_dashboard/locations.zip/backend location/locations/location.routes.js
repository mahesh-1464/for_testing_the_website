const router = require("express").Router();
const controller = require("./location.controller");

router.get("/", controller.getAllLocations);
router.get("/:id", controller.getLocationById);
router.patch("/:id", controller.updateLocation);
router.post("/update", controller.updateLocation);
router.get("/track/:workerId", controller.getWorkerLocation);
router.post("/worker/update", controller.updateWorkerLocation);
router.get("/track/all", controller.getAllWorkerLocations);

module.exports = router;
