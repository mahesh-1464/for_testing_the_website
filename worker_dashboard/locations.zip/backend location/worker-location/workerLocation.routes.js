const router = require("express").Router();
const controller = require("./workerLocation.controller");

router.post("/update", controller.updateLocation);
router.get("/:workerId", controller.getLocation);
router.get("/", controller.getAll);

module.exports = router;