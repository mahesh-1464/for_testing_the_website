import React, { useEffect, useState, useMemo } from "react";
import { Box } from "@mui/material";
import axios from "axios";

import LocationList from "../components/location/LocationList";
import LocationDetail from "../components/location/LocationDetail";

/* ----------------------------------------------------
   DEMO DATA (READ ONLY)
---------------------------------------------------- */
// const initialLocations = [
//   {
//     id: 1,
//     dataCenter: "DC-01",
//     colo: "COLO A",
//     hall: "Hall 1",
//     zone: "Zone 3",
//     rackStart: 1,
//     rackEnd: 20,
//     status: "Active",
//     lat: 17.385,
//     lng: 78.4867,
//     movementNotification: true,
//     clientHistory: [
//       { date: "2025-11-02", client: "AWS", from: "Rack 5", to: "Rack 10" },
//       { date: "2025-12-01", client: "NETMAGIC", from: "Rack 10", to: "Rack 15" },
//     ],
//     taskCount: 12,
//     tasks: Array.from({ length: 5 }).map((_, i) => ({
//       id: `TASK-10${i + 1}`,
//       title: i % 2 === 0 ? "Daily Cleaning – Aisle" : "Rack Dusting",
//       status: i % 3 === 0 ? "In Progress" : "Completed",
//       priority: i % 2 === 0 ? "High" : "Medium",
//       assignedTo: i % 2 === 0 ? "Ravi Kumar" : "Anita Sharma",
//       gpsValid: true,
//       rack: i + 1,
//     })),
//     racks: Array.from({ length: 20 }).map((_, i) => ({
//       rackNumber: i + 1,
//       status:
//         i % 5 === 0 ? "Maintenance" : i % 3 === 0 ? "Busy" : "Active",
//       client: i % 2 === 0 ? "Amazon" : "NetMagic",
//       taskCount: Math.floor(Math.random() * 5),
//     })),
//     inventory: {
//       required: [
//         { item: "Floor Cleaner", qty: 2 },
//         { item: "Gloves", qty: 4 },
//         { item: "Dusting Cloth", qty: 5 },
//       ],
//       available: true,
//       pendingReturn: false,
//     },
//   },
// ];

/* ----------------------------------------------------
   WORKER LOCATION VIEW
---------------------------------------------------- */
export default function WorkerLocationView() {
  const [locations, setLocations] = useState([]);
  const [mode, setMode] = useState("list");
  const [selectedLocationId, setSelectedLocationId] = useState(null);

  const [statusFilter, setStatusFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [highlightSection, setHighlightSection] = useState(null);

  /* ---------------- FILTERED LIST ---------------- */
  const filteredLocations = useMemo(() => {
    return locations.filter((loc) => {
      const matchStatus =
        statusFilter === "All" || loc.status === statusFilter;

      const s = search.toLowerCase();
      const matchSearch =
        !s ||
        loc.colo.toLowerCase().includes(s) ||
        loc.hall.toLowerCase().includes(s) ||
        loc.zone.toLowerCase().includes(s) ||
        loc.dataCenter.toLowerCase().includes(s);

      return matchStatus && matchSearch;
    });
  }, [locations, statusFilter, search]);

  /* ---------------- SELECTED LOCATION ---------------- */
  const selectedLocation = useMemo(
    () => locations.find((l) => l.id === selectedLocationId) || null,
    [locations, selectedLocationId]
  );

  /* ---------------- HANDLERS ---------------- */
  const handleOpenDetails = (locId, section = null) => {
    setSelectedLocationId(locId);
    setMode("detail");
    setHighlightSection(section);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBackToList = () => {
    setMode("list");
    setSelectedLocationId(null);
    setHighlightSection(null);
  };

  /* ---------------- UI ---------------- */
  return (
    <Box sx={{ p: 3, bgcolor: "#e5edf9", minHeight: "100vh" }}>
      <Box
        sx={{
          maxWidth: "1240px",
          mx: "auto",
          p: 3,
          background: "white",
          borderRadius: 4,
          boxShadow: "0 18px 45px rgba(15,23,42,0.12)",
        }}
      >
        {mode === "list" ? (
          <LocationList
            locations={filteredLocations}
            totalCount={locations.length}
            statusFilter={statusFilter}
            onStatusFilterChange={setStatusFilter}
            search={search}
            onSearchChange={setSearch}
            onOpenDetails={handleOpenDetails}
            readOnly
          />
        ) : selectedLocation ? (
          <LocationDetail
            location={selectedLocation}
            onBack={handleBackToList}
            highlightSection={highlightSection}
            readOnly
          />
        ) : null}
      </Box>
    </Box>
  );
}
