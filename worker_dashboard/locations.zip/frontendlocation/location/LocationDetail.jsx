import React from "react";
import {
  Box,
  Typography,
  Button,
  Chip,
  Divider,
} from "@mui/material";

import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

/* Fix leaflet marker icon issue */
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1.1/images/marker-shadow.png",
});

export default function WorkerLocationDetail({ location, onBack }) {
  if (!location) return null;

  const position = [location.lat, location.lng];

  return (
    <Box>
      <Button onClick={onBack} sx={{ mb: 2 }}>
        ← Back to Locations
      </Button>

      <Typography variant="h5" fontWeight={700} gutterBottom>
        {location.colo} / {location.hall}
      </Typography>

      <Typography color="text.secondary">
        Data Center: {location.dataCenter}
      </Typography>
      <Typography color="text.secondary">
        Zone: {location.zone}
      </Typography>

      <Divider sx={{ my: 3 }} />

      {/* MAP */}
      <Typography variant="h6" fontWeight={700} gutterBottom>
        Work Location Map
      </Typography>

      <Box
        sx={{
          height: 280,
          borderRadius: 2,
          overflow: "hidden",
          border: "1px solid #ddd",
          mb: 4,
        }}
      >
        <MapContainer
          center={position}
          zoom={16}
          style={{ height: "100%", width: "100%" }}
          scrollWheelZoom={false}
        >
          <TileLayer
            attribution="© OpenStreetMap contributors"
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          <Marker position={position}>
            <Popup>
              <strong>{location.colo}</strong>
              <br />
              {location.hall} – {location.zone}
            </Popup>
          </Marker>
        </MapContainer>
      </Box>

      {/* WORK CELLS */}
      <Typography variant="h6" fontWeight={700} gutterBottom>
        My Work Location
      </Typography>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))",
          gap: 2,
        }}
      >
        {location.tasks.map((task) => (
          <Box
            key={task.id}
            sx={{
              p: 2,
              borderRadius: 2,
              border: "1px solid #c7d2fe",
              bgcolor: "#f1f5ff",
            }}
          >
            <Typography fontWeight={600}>
              Cell {task.cell}
            </Typography>

            <Typography variant="body2" sx={{ my: 0.5 }}>
              {task.title}
            </Typography>

            <Chip
              label={task.status}
              size="small"
              color={
                task.status === "Completed"
                  ? "success"
                  : task.status === "In Progress"
                  ? "warning"
                  : "default"
              }
            />
          </Box>
        ))}
      </Box>
    </Box>
  );
}
