import React from "react";
import {
  Box,
  Typography,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Chip,
  IconButton,
  Tooltip,
} from "@mui/material";

import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import RoomIcon from "@mui/icons-material/Room";

export default function LocationList({
  locations,
  totalCount,
  statusFilter,
  onStatusFilterChange,
  search,
  onSearchChange,
  onOpenDetails,
}) {
  return (
    <Box>
      {/* HEADER */}
      <Typography variant="h4" sx={{ fontWeight: 800, mb: 3 }}>
        Locations Management
      </Typography>

      {/* SEARCH + FILTERS */}
      <Box
        sx={{
          display: "flex",
          gap: 2,
          mb: 3,
          alignItems: "center",
        }}
      >
        <TextField
          fullWidth
          size="small"
          placeholder="Search COLO / Hall"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
        />

        <FormControl size="small" sx={{ width: 150 }}>
          <InputLabel>Status</InputLabel>
          <Select
            value={statusFilter}
            label="Status"
            onChange={(e) => onStatusFilterChange(e.target.value)}
          >
            <MenuItem value="All">All</MenuItem>
            <MenuItem value="Active">Active</MenuItem>
            <MenuItem value="Busy">Busy</MenuItem>
            <MenuItem value="Under Maintenance">Under Maintenance</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* TABLE WRAPPER */}
      <Box
        sx={{
          borderRadius: 3,
          overflow: "hidden",
          border: "1px solid #e5e7eb",
        }}
      >
        {/* TABLE HEADER */}
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "2fr 1fr 1fr 1fr",
            bgcolor: "#f1f5f9",
            p: 2,
            fontWeight: 700,
            borderBottom: "1px solid #e5e7eb",
          }}
        >
          <Box>COLO / Hall</Box>
          <Box>Status</Box>
          <Box>Coordinates</Box>
          <Box>Actions</Box>
        </Box>

        {/* TABLE ROWS */}
        {locations.map((loc) => (
          <Box
            key={loc.id}
            sx={{
              display: "grid",
              gridTemplateColumns: "2fr 1fr 1fr 1fr",
              p: 2,
              alignItems: "center",
              borderBottom: "1px solid #f0f0f0",
              "&:hover": { background: "#f8fafc" },
            }}
          >
            {/* COLO + HALL */}
            <Box sx={{ fontWeight: 500 }}>
              {loc.colo} / {loc.hall}
            </Box>

            {/* STATUS */}
            <Box>
              <Chip
                label={loc.status}
                color={
                  loc.status === "Active"
                    ? "success"
                    : loc.status === "Busy"
                    ? "warning"
                    : "error"
                }
                size="small"
              />
            </Box>

            {/* COORDINATES */}
            <Box sx={{ color: "#555" }}>
              {loc.lat}, {loc.lng}
            </Box>

            {/* ACTIONS */}
            <Box sx={{ display: "flex", gap: 1 }}>
              <Tooltip title="View Details">
                <IconButton onClick={() => onOpenDetails(loc.id)}>
                  <VisibilityIcon fontSize="small" />
                </IconButton>
              </Tooltip>
{/* 
              <Tooltip title="Edit">
                <IconButton onClick={() => onOpenDetails(loc.id)}>
                  <EditIcon fontSize="small" />
                </IconButton>
              </Tooltip> */}

              <Tooltip title="Open Map">
                <IconButton
                  onClick={() => onOpenDetails(loc.id, "gps")}
                >
                  <RoomIcon fontSize="small" color="primary" />
                </IconButton>
              </Tooltip>

              <Tooltip title="Delete">
                <IconButton>
                  <DeleteIcon fontSize="small" color="error" />
                </IconButton>
              </Tooltip>
            </Box>
          </Box>
        ))}

        {locations.length === 0 && (
          <Box
            sx={{
              p: 3,
              textAlign: "center",
              color: "gray",
              fontSize: "1rem",
            }}
          >
            No locations found.
          </Box>
        )}
      </Box>
    </Box>
  );
}
